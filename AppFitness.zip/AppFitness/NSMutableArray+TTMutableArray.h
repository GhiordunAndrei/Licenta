//
//  NSMutableArray+TTMutableArray.h
//  AppFitness
//
//  Created by Andrei on 11/04/14.
//  Copyright (c) 2014 Licenta. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (TTMutableArray)

- (void)shuffle;

@end
