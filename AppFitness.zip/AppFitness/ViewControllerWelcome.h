//
//  ViewControllerWelcome.h
//  AppFitness
//
//  Created by Andrei on 04/04/14.
//  Copyright (c) 2014 Licenta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewControllerWelcome : UIViewController

@end
