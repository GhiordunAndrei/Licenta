//
//  IMViewController.h
//  IMViewWithBorderedImage
//
//  Created by Igor Mischenko on 28.09.12.
//  Copyright (c) 2012 Igor Mischenko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IMViewController : UIViewController

@end
